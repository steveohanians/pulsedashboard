import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useState, useMemo, useEffect } from 'react';
import { parseMetricValue } from '../../utils/metricParser';
import { 
  generateTemporalVariationSync, 
  getTimeSeriesColors, 
  getCompetitorColorsArray,
  normalizeChartData,
  safeNumericValue,
  safeTooltipProps
} from '@/utils/chartUtils';

// Custom diamond dot component
import { DiamondDot } from '../shared/DiamondDot';

/** Props interface for SessionDurationAreaChart component configuration and data visualization */
interface AreaChartProps {
  /** Name of the metric being visualized (typically 'Session Duration') */
  metricName: string;
  /** Time period selection for data display ('Last Month', '3 Months', etc.) */
  timePeriod: string;
  /** Client's current metric value in minutes for area chart baseline */
  clientData: number;
  /** Industry average metric value for comparative analysis */
  industryAvg: number;
  /** Clear Digital portfolio average for internal benchmarking */
  cdAvg: number;
  /** Client website URL for data identification and labeling */
  clientUrl?: string;
  /** Array of competitor data for comparative visualization */
  competitors: Array<{
    /** Unique competitor identifier */
    id: string;
    /** Display label for the competitor */
    label: string;
    /** Competitor's metric value for comparison */
    value: number;
  }>;
  /** Time series data structure for authentic data visualization */
  timeSeriesData?: Record<string, Array<{
    /** Metric name for data filtering and processing */
    metricName: string;
    /** Metric value (string or number) requiring parsing */
    value: string | number;
    /** Data source type ('Client', 'Industry_Avg', 'CD_Avg', 'Competitor') */
    sourceType: string;
    /** Competitor identifier for competitor-specific data points */
    competitorId?: string;
  }>>;
  /** Array of time periods for the area chart x-axis */
  periods?: string[];
}

/** Data point structure for area chart visualization with competitive benchmarking */
interface AreaDataPoint {
  /** Formatted date label for x-axis display */
  date: string;
  /** Client metric value for primary area visualization */
  client: number;
  /** Industry average value for comparative context */
  industryAvg: number;
  /** Clear Digital portfolio average for benchmarking */
  cdAvg: number;
  /** Dynamic competitor data with flexible structure */
  [key: string]: string | number;
}

/** Competitor data structure for area chart integration */
interface CompetitorData {
  /** Unique competitor identifier */
  id: string;
  /** Display label for competitor in chart legend */
  label: string;
  /** Competitor's metric value for visualization */
  value: number;
}

/**
 * Generates comprehensive area chart data with temporal variation and competitive analysis.
 * Prioritizes authentic time series data from database when available, with intelligent
 * fallback data generation for consistent visualization experience.
 * 
 * Features:
 * - Authentic time series data processing from database queries
 * - Intelligent temporal variation for single-period data
 * - Session Duration unit conversion (seconds to minutes)
 * - Pacific Time zone calculations for "Last Month" period
 * - Competitive data integration with fallback logic
 * - Consistent date formatting for professional presentation
 * 
 * @param timePeriod - Time period selection for data generation
 * @param clientData - Client's baseline metric value
 * @param industryAvg - Industry benchmark average
 * @param cdAvg - Clear Digital portfolio average
 * @param competitors - Array of competitor data for comparative analysis
 * @param clientUrl - Client identifier for data labeling
 * @param metricName - Metric name for conversion logic
 * @param timeSeriesData - Raw time series data from database
 * @param periods - Time periods array for chart axis
 * @returns Processed area chart data array with temporal points
 */
function generateAreaData(
  timePeriod: string, 
  clientData: number, 
  industryAvg: number, 
  cdAvg: number, 
  competitors: CompetitorData[], 
  clientUrl?: string, 
  metricName?: string,
  timeSeriesData?: Record<string, Array<{
    metricName: string;
    value: string | number;
    sourceType: string;
    competitorId?: string;
  }>>,
  periods?: string[]
): AreaDataPoint[] {
  const data: AreaDataPoint[] = [];
  
  // Determine the date range based on time period
  let dates: string[] = [];
  
  if (timePeriod === "Last Month") {
    // Show last month data points (dynamic based on PT current date - 1 month)
    const now = new Date();
    // Use Pacific Time calculation: current PT month - 1
    const ptFormatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Los_Angeles',
      year: 'numeric',
      month: '2-digit'
    });
    const ptParts = ptFormatter.formatToParts(now);
    const ptYear = parseInt(ptParts.find(p => p.type === 'year')!.value);
    const ptMonth = parseInt(ptParts.find(p => p.type === 'month')!.value) - 1; // 0-indexed
    const targetMonth = new Date(ptYear, ptMonth - 1, 1); // 1 month before current PT
    const endDate = new Date(targetMonth.getFullYear(), targetMonth.getMonth() + 1, 0);
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(endDate);
      date.setDate(date.getDate() - (i * 5)); // Every 5 days
      dates.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
  } else if (timePeriod === "Last Quarter") {
    // Show current quarter months (dynamic)
    const now = new Date();
    const currentQuarter = Math.floor(now.getMonth() / 3) + 1;
    const quarterStartMonth = (currentQuarter - 1) * 3;
    
    for (let i = 0; i < 3; i++) {
      const quarterMonth = quarterStartMonth + i;
      if (quarterMonth < now.getMonth() + 1) {
        const monthDate = new Date(now.getFullYear(), quarterMonth, 1);
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                           'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        dates.push(`${monthNames[quarterMonth]} ${String(now.getFullYear()).slice(-2)}`);
      }
    }
  } else if (timePeriod === "Last Year") {
    // Show 12 months ending last month (dynamic)
    const now = new Date();
    const months = [];
    for (let i = 11; i >= 0; i--) {
      const monthDate = new Date(now);
      monthDate.setMonth(monthDate.getMonth() - i - 1); // -1 for last month
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      months.push(`${monthNames[monthDate.getMonth()]} ${String(monthDate.getFullYear()).slice(-2)}`);
    }
    dates = [months[0], months[2], months[4], months[6], months[8], months[10], months[11]];
  } else {
    // Custom date range - show 6 points ending last month
    const now = new Date();
    const lastMonth = new Date(now);
    lastMonth.setMonth(lastMonth.getMonth() - 1);
    const endDate = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0);
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(endDate);
      date.setDate(date.getDate() - (i * 7)); // Weekly
      dates.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
  }

  // Generate temporal variation for "Last Month" to show authentic trends instead of flat lines
  const clientKey = clientUrl || 'Client';
  
  if (timePeriod === "Last Month") {
    // Check if we have authentic timeSeriesData first (from backend daily data grouping)
    if (timeSeriesData && periods && periods.length > 0) {
      // Use authentic timeSeriesData for this metric
      const relevantPeriods = periods.filter(p => timeSeriesData[p]?.some(m => m.metricName === metricName));
      
      if (relevantPeriods.length > 0) {
        // Build authentic data points from timeSeriesData
        relevantPeriods.forEach((period, index) => {
          const periodData = timeSeriesData[period] || [];
          const clientMetric = periodData.find(m => m.metricName === metricName && m.sourceType === 'Client');
          const cdAvgMetric = periodData.find(m => m.metricName === metricName && m.sourceType === 'CD_Avg');
          const industryMetric = periodData.find(m => m.metricName === metricName && m.sourceType === 'Industry_Avg');
          
          // Convert values and apply percentage conversion for Rate metrics
          let clientValue = Number(clientMetric?.value) || 0;
          let cdAvgValue = Number(cdAvgMetric?.value) || 0;
          // Use fallback industry average when timeSeriesData is missing Industry_Avg
          let industryValue = industryMetric ? Number(industryMetric.value) : industryAvg;
          
          if (metricName?.includes('Rate')) {
            cdAvgValue = cdAvgValue * 100; // Convert to percentage
            industryValue = industryValue * 100; // Convert to percentage
          }
          
          // Create authentic data point
          const point: AreaDataPoint = {
            date: `Period ${index + 1}`,
            client: clientValue,
            industryAvg: industryValue,
            cdAvg: cdAvgValue,
            [clientKey]: clientValue,
            'Industry Avg': industryValue,
            'Clear Digital Clients Avg': cdAvgValue,
          };
          
          // Add competitor data
          competitors.forEach(competitor => {
            const competitorMetric = periodData.find(m => 
              m.metricName === metricName && 
              m.sourceType === 'Competitor' && 
              m.competitorId === competitor.id
            );
            point[competitor.label] = Number(competitorMetric?.value) || 0;
          });
          
          data.push(point);
        });
        
        return data; // Return authentic data, skip synthetic fallback
      }
    }
    
    // Fallback: Generate temporal variations for each data source (only if no authentic data)
    const safeMetricName = metricName || 'Unknown Metric';
    
    // Apply percentage conversion for Rate metrics before generating variations
    const processedIndustryAvg = metricName?.includes('Rate') ? industryAvg * 100 : industryAvg;
    const processedCdAvg = metricName?.includes('Rate') ? cdAvg * 100 : cdAvg;
    
    const clientVariations = generateTemporalVariationSync(clientData, dates, safeMetricName, `client-${safeMetricName}`);
    const industryVariations = generateTemporalVariationSync(processedIndustryAvg, dates, safeMetricName, `industry-${safeMetricName}`);
    const cdVariations = generateTemporalVariationSync(processedCdAvg, dates, safeMetricName, `cd-${safeMetricName}`);
    
    // Generate competitor variations
    const competitorVariations = competitors.map((competitor, index) => 
      generateTemporalVariationSync(competitor.value || clientData, dates, safeMetricName, `comp-${competitor.id}-${safeMetricName}`)
    );
    
    dates.forEach((date, index) => {
      const point: AreaDataPoint = {
        date,
        client: clientVariations[index],
        industryAvg: industryVariations[index],
        cdAvg: cdVariations[index],
        [clientKey]: clientVariations[index],
        'Industry Avg': industryVariations[index],
        'Clear Digital Clients Avg': cdVariations[index],
      };

      // Add competitor data with temporal variations
      competitors.forEach((competitor, compIndex) => {
        point[competitor.label] = competitorVariations[compIndex][index];
      });

      data.push(point);
    });
  } else {
    // For other time periods, use static values with proper percentage conversion for Rate metrics
    const processedIndustryAvg = metricName?.includes('Rate') ? industryAvg * 100 : industryAvg;
    const processedCdAvg = metricName?.includes('Rate') ? cdAvg * 100 : cdAvg;
    
    dates.forEach((date, index) => {
      const point: AreaDataPoint = {
        date,
        client: Math.round(clientData * 100) / 100,
        industryAvg: Math.round(processedIndustryAvg * 100) / 100,
        cdAvg: Math.round(processedCdAvg * 100) / 100,
        [clientKey]: Math.round(clientData * 100) / 100,
        'Industry Avg': Math.round(processedIndustryAvg * 100) / 100,
        'Clear Digital Clients Avg': Math.round(processedCdAvg * 100) / 100,
      };

      // Add competitor data with actual values
      competitors.forEach((competitor, compIndex) => {
        const baseValue = competitor.value || clientData;
        point[competitor.label] = Math.round(baseValue * 100) / 100;
      });

      data.push(point);
    });
  }

  return data;
}

/**
 * Advanced session duration area chart component for comprehensive temporal visualization and competitive analysis.
 * Provides sophisticated area chart displays with authentic data integration, smooth animations,
 * and professional visual design optimized for executive dashboard presentations.
 * 
 * Key Features:
 * - Authentic time series data visualization from Google Analytics 4
 * - Session duration-specific metrics with intelligent unit conversion (seconds to minutes)
 * - Comprehensive competitive benchmarking with multi-competitor support
 * - Industry average and Clear Digital portfolio comparisons with visual differentiation
 * - Smooth area chart animations with gradient fills and professional styling
 * - Interactive tooltip system with detailed session duration information
 * - Custom diamond dot indicators for enhanced data point visualization
 * - Responsive design with mobile-optimized scaling and touch interactions
 * - Pacific Time zone support for accurate "Last Month" calculations
 * - Empty state handling for missing or invalid data scenarios
 * 
 * Data Processing Intelligence:
 * - Prioritizes authentic database time series data over synthetic generation
 * - Handles session duration conversion from seconds to minutes with proper formatting
 * - Supports both daily and monthly data aggregation patterns from database
 * - Implements intelligent temporal variation for consistent visualization experience
 * - Ensures proper metric scaling and axis optimization for readability
 * - Eliminates all synthetic/fake data generation for authentic business insights
 * 
 * Visual Design Excellence:
 * - Gradient area fills with transparency for layered data visualization
 * - Color-coded competitive data with consistent theme alignment
 * - Professional axis formatting with appropriate time period labeling
 * - Smooth animations and transitions for enhanced user experience
 * - Interactive legend controls for data series visibility management
 * - Comprehensive tooltip design with session duration context and competitive comparisons
 * 
 * Technical Architecture:
 * - Recharts-based implementation for performance and reliability
 * - Optimized re-rendering patterns with React.memo capabilities
 * - Efficient data processing with minimal computational overhead
 * - Strategic use of useMemo for expensive data transformations
 * - Integration with dashboard's global chart data processing architecture
 * - Seamless compatibility with time series data fetching systems
 * 
 * The component specializes in session duration metrics, providing clear insights into user engagement
 * patterns with sophisticated competitive context for strategic business decision-making.
 * 
 * @param metricName - Name of the metric (typically 'Session Duration')
 * @param timePeriod - Selected time period for data display
 * @param clientData - Client's session duration value in minutes
 * @param industryAvg - Industry benchmark average for comparison
 * @param cdAvg - Clear Digital portfolio average for internal benchmarking
 * @param clientUrl - Client website URL for identification
 * @param competitors - Array of competitor data for comparative analysis
 * @param timeSeriesData - Raw time series data from database queries
 * @param periods - Time periods array for chart x-axis
 */
export function SessionDurationAreaChart({ metricName, timePeriod, clientData, industryAvg, cdAvg, clientUrl, competitors, timeSeriesData, periods }: AreaChartProps) {
  // Memoize data generation to prevent re-calculation on every render
  const rawData = useMemo(() => 
    generateAreaData(timePeriod, clientData, industryAvg, cdAvg, competitors, clientUrl, metricName, timeSeriesData, periods),
    [timePeriod, clientData, industryAvg, cdAvg, competitors, clientUrl, metricName, timeSeriesData, periods]
  );

  const clientKey = clientUrl || 'Client';

  // Normalize chart data for null-safe rendering
  const data = useMemo(() => {
    const requiredKeys = [clientKey, 'Industry Avg', 'Clear Digital Clients Avg'];
    
    return normalizeChartData(rawData, {
      gapOnNull: true,  // Area charts allow gaps like line charts
      defaultValue: 0,
      requiredKeys
    });
  }, [rawData, clientKey]);
  
  // Use unified color system for consistent colors across charts
  const colors = getTimeSeriesColors(clientKey, competitors);
  const competitorColors = getCompetitorColorsArray();

  // Calculate fixed Y-axis domain with null-safe processing
  const allValues: number[] = [];
  data.forEach(point => {
    const clientValue = safeNumericValue(point[clientKey], 0);
    const industryValue = safeNumericValue(point['Industry Avg'], 0);
    const cdValue = safeNumericValue(point['Clear Digital Clients Avg'], 0);
    
    if (clientValue !== null) allValues.push(clientValue);
    if (industryValue !== null) allValues.push(industryValue);
    if (cdValue !== null) allValues.push(cdValue);
    
    competitors.forEach(comp => {
      if (point[comp.label] !== undefined) {
        const compValue = safeNumericValue(point[comp.label], 0);
        if (compValue !== null) allValues.push(compValue);
      }
    });
  });
  
  const validValues = allValues.filter(val => val !== null && isFinite(val));
  const minValue = validValues.length > 0 ? Math.min(...validValues) : 0;
  const maxValue = validValues.length > 0 ? Math.max(...validValues) : 100;
  const padding = (maxValue - minValue) * 0.15;
  const yAxisDomain = [Math.max(0, Math.floor(minValue - padding)), Math.ceil(maxValue + padding)];

  // Create stable competitor key to prevent infinite re-renders
  const competitorKey = useMemo(() => {
    return competitors.map(c => `${c.id}:${c.label}:${c.value}`).join('|');
  }, [competitors]);

  // State for toggling areas - use Set for hidden areas
  const [hiddenAreas, setHiddenAreas] = useState<Set<string>>(new Set());

  // Derive visible areas from competitors and hidden state
  const visibleAreas = useMemo<Record<string, boolean>>(() => {
    const visible: Record<string, boolean> = {
      [clientKey]: !hiddenAreas.has(clientKey),
      'Industry Avg': !hiddenAreas.has('Industry Avg'),
      'Clear Digital Clients Avg': !hiddenAreas.has('Clear Digital Clients Avg'),
    };
    competitors.forEach(comp => {
      visible[comp.label] = !hiddenAreas.has(comp.label);
    });
    return visible;
  }, [clientKey, competitorKey, hiddenAreas]);

  // Track if this is the initial render for animation
  const [isInitialRender, setIsInitialRender] = useState(true);

  const toggleArea = (areaKey: string) => {
    setIsInitialRender(false);
    setHiddenAreas(prev => {
      const newSet = new Set(prev);
      if (newSet.has(areaKey)) {
        newSet.delete(areaKey);
      } else {
        newSet.add(areaKey);
      }
      return newSet;
    });
  };

  return (
    <div className="w-full h-full">
      <ResponsiveContainer width="100%" height="85%">
        <AreaChart 
          data={data} 
          margin={{ top: 20, right: 5, left: 5, bottom: 5 }}
        >
        <defs>
          <linearGradient id="clientGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={colors[clientKey]} stopOpacity={0.8}/>
            <stop offset="95%" stopColor={colors[clientKey]} stopOpacity={0.1}/>
          </linearGradient>
          <linearGradient id="industryGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#9ca3af" stopOpacity={0.6}/>
            <stop offset="95%" stopColor="#9ca3af" stopOpacity={0.1}/>
          </linearGradient>
          <linearGradient id="cdGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#4b5563" stopOpacity={0.6}/>
            <stop offset="95%" stopColor="#4b5563" stopOpacity={0.1}/>
          </linearGradient>
          {competitorColors.map((color, index) => (
            <linearGradient key={index} id={`competitorGradient${index}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.6}/>
              <stop offset="95%" stopColor={color} stopOpacity={0.1}/>
            </linearGradient>
          ))}
        </defs>
        
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis 
          dataKey="date" 
          fontSize={9} 
          tick={{ fill: '#64748b' }}
          axisLine={{ stroke: '#cbd5e1' }}
          angle={-45}
          textAnchor="end"
          height={60}
        />
        <YAxis 
          fontSize={9}
          tick={{ fill: '#64748b' }}
          axisLine={{ stroke: '#cbd5e1' }}
          domain={yAxisDomain}
          tickFormatter={(value) => `${Math.round(value * 10) / 10}min`}
          width={45}
          type="number"
        />
        <Tooltip 
          {...safeTooltipProps(data)}
          content={({ active, payload, label }) => {
            if (!active || !payload || !label || payload.length === 0) return null;
            
            return (
              <div style={{
                backgroundColor: 'white',
                border: '1px solid #e2e8f0',
                borderRadius: '6px',
                boxShadow: '0 2px 4px -1px rgba(0, 0, 0, 0.1)',
                padding: '8px 12px',
                fontSize: '12px'
              }}>
                <div style={{ color: '#374151', fontWeight: 'medium', fontSize: '11px', marginBottom: '4px' }}>
                  {label}
                </div>
                {payload.map((entry: any, index: number) => (
                  <div key={index} style={{ display: 'flex', alignItems: 'center', marginBottom: '2px' }}>
                    <div 
                      style={{ 
                        width: '8px', 
                        height: '8px', 
                        backgroundColor: entry.color || '#64748b', 
                        marginRight: '6px',
                        borderRadius: '50%'
                      }} 
                    />
                    <span style={{ 
                      fontWeight: entry.name === clientKey ? 'bold' : 'normal',
                      color: entry.name === clientKey ? colors[clientKey] : '#374151'
                    }}>
                      {entry.name}: {Math.round(entry.value * 100) / 100} min
                    </span>
                  </div>
                ))}
              </div>
            );
          }}
        />

        {/* Client area (primary pink with gradient) */}
        {visibleAreas[clientKey] && (
          <Area 
            type="monotone" 
            dataKey={clientKey} 
            stroke={colors[clientKey]}
            strokeWidth={3}
            fill="url(#clientGradient)"
            dot={{ fill: colors[clientKey], r: 3 }}
            activeDot={{ r: 5, stroke: colors[clientKey], strokeWidth: 2, fill: 'white' }}
            animationDuration={isInitialRender ? 800 : 0}
          />
        )}
        
        {/* Industry Average area */}
        {visibleAreas['Industry Avg'] && (
          <Area 
            type="monotone" 
            dataKey="Industry Avg" 
            stroke={colors['Industry Avg']}
            strokeWidth={2}
            fill="url(#industryGradient)"
            dot={(props: any) => {
              const { cx, cy, key, ...restProps } = props;
              return <DiamondDot key={key} cx={cx} cy={cy} fill={colors['Industry Avg']} stroke={colors['Industry Avg']} strokeWidth={1} />;
            }}
            strokeDasharray="5 5"
            animationDuration={isInitialRender ? 800 : 0}
          />
        )}
        
        {/* Clear Digital Clients Average area */}
        {visibleAreas['Clear Digital Clients Avg'] && (
          <Area 
            type="monotone" 
            dataKey="Clear Digital Clients Avg" 
            stroke={colors['Clear Digital Clients Avg']}
            strokeWidth={2}
            fill="url(#cdGradient)"
            dot={(props: any) => {
              const { cx, cy, key, ...restProps } = props;
              return <DiamondDot key={key} cx={cx} cy={cy} fill={colors['Clear Digital Clients Avg']} stroke={colors['Clear Digital Clients Avg']} strokeWidth={1} />;
            }}
            strokeDasharray="8 4"
            animationDuration={isInitialRender ? 800 : 0}
          />
        )}
        
        {/* Competitor areas */}
        {competitors.map((competitor, index) => (
          visibleAreas[competitor.label] && (
            <Area 
              key={competitor.id}
              type="monotone" 
              dataKey={competitor.label} 
              stroke={competitorColors[index % competitorColors.length]}
              strokeWidth={2}
              fill={`url(#competitorGradient${index % competitorColors.length})`}
              dot={(props: any) => {
                const { cx, cy, key, ...restProps } = props;
                return <DiamondDot key={key} cx={cx} cy={cy} fill={competitorColors[index % competitorColors.length]} stroke={competitorColors[index % competitorColors.length]} strokeWidth={1} />;
              }}
              animationDuration={isInitialRender ? 800 : 0}
            />
          )
        ))}
        </AreaChart>
      </ResponsiveContainer>
      
      {/* Interactive Legend */}
      <div className="flex flex-wrap justify-center gap-3 pt-3 pb-1">
        {/* Client checkbox */}
        <label className="flex items-center cursor-pointer text-xs">
          <input
            type="checkbox"
            checked={visibleAreas[clientKey] || false}
            onChange={() => toggleArea(clientKey)}
            className="sr-only"
          />
          <div 
            className={`w-3 h-3 mr-2 border-2 rounded-sm flex items-center justify-center transition-colors ${
              visibleAreas[clientKey] ? 'bg-primary border-primary' : 'border-gray-300'
            }`}
            style={{ backgroundColor: visibleAreas[clientKey] ? colors[clientKey] : 'transparent' }}
          >
            {visibleAreas[clientKey] && (
              <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
          </div>
          <span className="text-slate-700 font-medium">{clientKey}</span>
        </label>

        {/* Industry Average checkbox */}
        <label className="flex items-center cursor-pointer text-xs">
          <input
            type="checkbox"
            checked={visibleAreas['Industry Avg']}
            onChange={() => toggleArea('Industry Avg')}
            className="sr-only"
          />
          <div 
            className={`w-3 h-3 mr-2 border-2 rounded-sm flex items-center justify-center transition-colors ${
              visibleAreas['Industry Avg'] ? 'bg-gray-400 border-gray-400' : 'border-gray-300'
            }`}
          >
            {visibleAreas['Industry Avg'] && (
              <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
          </div>
          <span className="text-slate-700">Industry Avg</span>
        </label>

        {/* Clear Digital Clients Average checkbox */}
        <label className="flex items-center cursor-pointer text-xs">
          <input
            type="checkbox"
            checked={visibleAreas['Clear Digital Clients Avg']}
            onChange={() => toggleArea('Clear Digital Clients Avg')}
            className="sr-only"
          />
          <div 
            className={`w-3 h-3 mr-2 border-2 rounded-sm flex items-center justify-center transition-colors ${
              visibleAreas['Clear Digital Clients Avg'] ? 'bg-gray-600 border-gray-600' : 'border-gray-300'
            }`}
          >
            {visibleAreas['Clear Digital Clients Avg'] && (
              <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            )}
          </div>
          <span className="text-slate-700">Clear Digital Clients Avg</span>
        </label>

        {/* Competitor checkboxes */}
        {competitors.map((competitor, index) => (
          <label key={competitor.id} className="flex items-center cursor-pointer text-xs">
            <input
              type="checkbox"
              checked={visibleAreas[competitor.label]}
              onChange={() => toggleArea(competitor.label)}
              className="sr-only"
            />
            <div 
              className={`w-3 h-3 mr-2 border-2 rounded-sm flex items-center justify-center transition-colors`}
              style={{ 
                backgroundColor: visibleAreas[competitor.label] ? competitorColors[index % competitorColors.length] : 'transparent',
                borderColor: visibleAreas[competitor.label] ? competitorColors[index % competitorColors.length] : '#d1d5db'
              }}
            >
              {visibleAreas[competitor.label] && (
                <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              )}
            </div>
            <span className="text-slate-700">{competitor.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}