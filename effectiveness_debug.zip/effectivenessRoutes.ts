/**
 * Website Effectiveness API Routes
 * 
 * Endpoints for website effectiveness scoring and evidence retrieval
 */

import { Router } from 'express';
import { requireAuth, requireAdmin } from '../auth';
import { storage } from '../storage';
import { EnhancedWebsiteEffectivenessScorer } from '../services/effectiveness/enhancedScorer';
import { EffectivenessConfigManager } from '../services/effectiveness/config';
import { screenshotService } from '../services/effectiveness/screenshot';
import logger from '../utils/logging/logger';
import { z } from 'zod';
import { db } from '../db';
import { effectivenessRuns } from '@shared/schema';
import { and, eq, or, desc, sql, isNotNull } from 'drizzle-orm';

const router = Router();
const enhancedScorer = new EnhancedWebsiteEffectivenessScorer();
const configManager = EffectivenessConfigManager.getInstance();

/**
 * Get tier number for a criterion
 */
function getCriterionTier(criterion: string): number {
  const tierMap: Record<string, number> = {
    'ux': 1,
    'trust': 1,
    'accessibility': 1,
    'seo': 1,
    'positioning': 2,
    'brand_story': 2,
    'ctas': 2,
    'speed': 3
  };
  return tierMap[criterion] || 1;
}

// Request/Response schemas
const refreshRequestSchema = z.object({
  force: z.boolean().optional()
});

/**
 * Score a website with timeout protection and progressive updates
 */
async function scoreWithTimeout(url: string, runId?: string, timeoutMs: number = 90000): Promise<any> {
  return Promise.race([
    enhancedScorer.scoreWebsiteProgressive(url, runId, async (status, progress, results) => {
      // Progressive status updates are handled inside enhancedScorer
      logger.info('Progressive scoring update', { url, runId, status, progress });
    }),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error(`Scoring timeout after ${timeoutMs/1000} seconds`)), timeoutMs)
    )
  ]);
}

/**
 * Score a website without progressive updates (for competitors)
 */
async function scoreWithTimeoutBasic(url: string, timeoutMs: number = 90000): Promise<any> {
  return Promise.race([
    enhancedScorer.scoreWebsite(url),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error(`Scoring timeout after ${timeoutMs/1000} seconds`)), timeoutMs)
    )
  ]);
}

/**
 * Clean up stuck runs older than threshold
 */
async function cleanupStuckRuns(clientId: string): Promise<void> {
  const stuckThreshold = 5; // 5 minutes
  
  const stuckRuns = await db.update(effectivenessRuns)
    .set({
      status: 'failed',
      progress: 'Run timed out after 5 minutes - please retry'
    })
    .where(and(
      eq(effectivenessRuns.clientId, clientId),
      or(
        eq(effectivenessRuns.status, 'pending'),
        eq(effectivenessRuns.status, 'initializing'),
        eq(effectivenessRuns.status, 'scraping'),
        eq(effectivenessRuns.status, 'analyzing'),
        eq(effectivenessRuns.status, 'generating_insights')
      ),
      sql`created_at < NOW() - INTERVAL '${sql.raw(stuckThreshold.toString())} minutes'`
    ));
  
  if (stuckRuns.rowCount > 0) {
    logger.info('Cleaned up stuck runs', {
      clientId,
      count: stuckRuns.rowCount
    });
  }
}

/**
 * GET /api/effectiveness/:clientId/latest
 * Get the most recent effectiveness score for a client
 */
router.get('/latest/:clientId', requireAuth, async (req, res) => {
  try {
    const { clientId } = req.params;
    
    logger.info('Fetching latest effectiveness score', { clientId });

    // Get client to verify access and get website URL
    const client = await storage.getClient(clientId);
    if (!client) {
      return res.status(404).json({
        code: 'CLIENT_NOT_FOUND',
        message: 'Client not found'
      });
    }

    // Check user access
    if (req.user?.role !== 'Admin' && req.user?.clientId !== clientId) {
      return res.status(403).json({
        code: 'FORBIDDEN',
        message: 'Access denied'
      });
    }

    // Auto-fail runs stuck for more than 5 minutes
    const stuckRuns = await db
      .select()
      .from(effectivenessRuns)
      .where(and(
        eq(effectivenessRuns.clientId, clientId),
        or(
          eq(effectivenessRuns.status, 'pending'),
          eq(effectivenessRuns.status, 'initializing'),
          eq(effectivenessRuns.status, 'scraping'),
          eq(effectivenessRuns.status, 'analyzing')
        ),
        sql`created_at < NOW() - INTERVAL '${sql.raw('5')} minutes'`
      ));

    if (stuckRuns.length > 0) {
      // Mark stuck runs as failed
      for (const stuckRun of stuckRuns) {
        await storage.updateEffectivenessRun(stuckRun.id, {
          status: 'failed',
          progress: 'Run timed out - please retry'
        });
      }
      
      logger.warn('Auto-failed stuck runs', {
        clientId,
        stuckRunIds: stuckRuns.map(r => r.id)
      });
    }

    // Get latest effectiveness run
    const latestRun = await storage.getLatestEffectivenessRun(clientId);
    
    if (!latestRun) {
      return res.json({
        client,
        run: null,
        hasData: false
      });
    }

    // Get criterion scores for the run
    const criterionScores = await storage.getCriterionScores(latestRun.id);
    
    // Ensure we have valid data to show
    if (!criterionScores || criterionScores.length === 0) {
      logger.warn('No criterion scores found for latest run', {
        clientId,
        runId: latestRun.id,
        runStatus: latestRun.status,
        runCreatedAt: latestRun.createdAt
      });
      
      // If the run is still in progress, show it with empty scores
      if (['pending', 'initializing', 'scraping', 'analyzing', 'tier1_analyzing', 'tier2_analyzing', 'tier3_analyzing', 'generating_insights'].includes(latestRun.status)) {
        logger.info('Run is still in progress, showing with empty scores', { clientId, runId: latestRun.id });
      } else {
        // Run is complete but has no scores - this is a problem
        logger.error('Completed run has no criterion scores - data corruption?', {
          clientId,
          runId: latestRun.id,
          status: latestRun.status
        });
      }
    }
    
    // Get competitor effectiveness data
    logger.info('Fetching competitor effectiveness data', {
      clientId,
      function: 'getLatestEffectiveness',
      step: 'fetchingCompetitors'
    });

    const competitors = await storage.getCompetitorsByClient(clientId);
    
    logger.info('Found competitors for client', {
      clientId,
      competitorCount: competitors.length,
      competitors: competitors.map(c => ({
        id: c.id,
        domain: c.domain,
        label: c.label,
        status: c.status
      }))
    });

    const competitorEffectivenessData = [];
    
    for (const competitor of competitors) {
      logger.info('Processing competitor effectiveness data', {
        clientId,
        competitorId: competitor.id,
        competitorDomain: competitor.domain,
        competitorLabel: competitor.label
      });

      const competitorRun = await storage.getLatestEffectivenessRunByCompetitor(clientId, competitor.id);
      
      if (competitorRun) {
        const competitorScores = await storage.getCriterionScores(competitorRun.id);
        
        logger.info('Found competitor effectiveness run', {
          clientId,
          competitorId: competitor.id,
          runId: competitorRun.id,
          status: competitorRun.status,
          overallScore: competitorRun.overallScore,
          criterionScoresCount: competitorScores.length
        });
        
        competitorEffectivenessData.push({
          competitor,
          run: {
            ...competitorRun,
            criterionScores: competitorScores
          }
        });
      } else {
        logger.info('No effectiveness run found for competitor', {
          clientId,
          competitorId: competitor.id,
          competitorDomain: competitor.domain
        });
      }
    }

    // Aggregate progress from client run + all active competitor runs
    let overallStatus = latestRun.status;
    let overallProgress = latestRun.progress;
    
    // Get all recent competitor runs with their current status
    const activeCompetitorRuns = competitors.length > 0 ? await db
        .select()
        .from(effectivenessRuns)
        .where(and(
          eq(effectivenessRuns.clientId, clientId),
          isNotNull(effectivenessRuns.competitorId),
          sql`created_at >= NOW() - INTERVAL '${sql.raw('2')} minutes'`
        ))
        .orderBy(desc(effectivenessRuns.createdAt)) : [];
    
    if (competitors.length > 0) {

      // Find the most recent active competitor run in sequential order
      // Priority: currently running > most recently created
      const runningStates = ['pending', 'initializing', 'scraping', 'tier1_analyzing', 'tier2_analyzing', 'tier3_analyzing'];
      const completedStates = ['tier1_complete', 'tier2_complete', 'generating_insights'];
      
      // First try to find a currently running competitor
      let activeRun = activeCompetitorRuns.find(run => runningStates.includes(run.status));
      
      // If no running competitors, check for recently completed ones showing progress
      if (!activeRun) {
        activeRun = activeCompetitorRuns.find(run => completedStates.includes(run.status));
      }

      if (activeRun) {
        // Show progress from the active competitor run
        const competitor = competitors.find(c => c.id === activeRun.competitorId);
        const competitorName = competitor?.label || competitor?.domain || 'competitor';
        
        overallStatus = 'analyzing';
        
        // Map competitor status to user-friendly progress message
        switch (activeRun.status) {
          case 'pending':
          case 'initializing':
            overallProgress = `Starting ${competitorName} analysis...`;
            break;
          case 'scraping':
            overallProgress = `Collecting ${competitorName} data...`;
            break;
          case 'analyzing':
          case 'tier1_analyzing':
            overallProgress = `Scoring ${competitorName} criteria...`;
            break;
          case 'tier1_complete':
            overallProgress = `${competitorName} quick analysis complete`;
            break;
          case 'tier2_analyzing':
            overallProgress = `Enhanced ${competitorName} analysis...`;
            break;
          case 'tier2_complete':
            overallProgress = `${competitorName} enhanced analysis complete`;
            break;
          case 'tier3_analyzing':
            overallProgress = `${competitorName} performance analysis...`;
            break;
          case 'generating_insights':
            overallProgress = `Generating ${competitorName} insights...`;
            break;
          default:
            overallProgress = `Analyzing ${competitorName}...`;
        }
      } else if (latestRun.status === 'completed') {
        // Client is done, no active competitors, check if all competitors are done
        const allCompletedOrFailed = activeCompetitorRuns.length === 0 || 
          activeCompetitorRuns.every(run => ['completed', 'failed'].includes(run.status));
        
        if (allCompletedOrFailed) {
          // All analysis truly complete
          overallProgress = latestRun.progress || `All analysis completed - ${client.name} and ${competitors.length} competitor${competitors.length > 1 ? 's' : ''} analyzed`;
        } else {
          // Some competitors might still be pending/queued
          const pendingCount = activeCompetitorRuns.filter(run => 
            !['completed', 'failed'].includes(run.status)
          ).length;
          overallProgress = `Preparing competitor analysis... (${pendingCount} pending)`;
          overallStatus = 'analyzing';
        }
      }
    }
    
    const response = {
      client,
      run: {
        ...latestRun,
        // Override status and progress to reflect overall completion
        status: overallStatus,
        progress: overallProgress,
        criterionScores
      },
      competitorEffectivenessData,
      hasData: true
    };

    // Debug logging for status transitions
    logger.info('Status aggregation result', {
      clientId,
      clientRunStatus: latestRun.status,
      overallStatus,
      overallProgress,
      activeCompetitorRunsCount: competitors.length > 0 ? activeCompetitorRuns.length : 0,
      competitorStatuses: competitors.length > 0 ? activeCompetitorRuns.map(run => ({
        competitorId: run.competitorId,
        status: run.status,
        createdAt: run.createdAt
      })) : []
    });

    logger.info('Effectiveness data response prepared', {
      clientId,
      overallStatus,
      overallProgress,
      clientRunStatus: latestRun.status,
      criteriaCount: criterionScores.length,
      hasInsights: !!latestRun.aiInsights,
      competitorEffectivenessDataCount: competitorEffectivenessData.length,
      finalResponse: {
        hasData: response.hasData,
        clientOverallScore: response.run?.overallScore,
        competitorData: competitorEffectivenessData.map(cd => ({
          competitorLabel: cd.competitor.label,
          overallScore: cd.run.overallScore,
          criterionScoresCount: cd.run.criterionScores.length
        }))
      }
    });

    // Add comprehensive response debugging
    logger.info('API Response Summary', {
      clientId,
      hasData: response.hasData,
      runExists: !!response.run,
      runStatus: response.run?.status,
      runProgress: response.run?.progress,
      criterionScoresCount: response.run?.criterionScores?.length || 0,
      competitorDataCount: response.competitorEffectivenessData?.length || 0,
      overallScore: response.run?.overallScore,
      hasAiInsights: !!response.run?.aiInsights
    });

    res.json(response);

  } catch (error) {
    logger.error('Failed to fetch effectiveness data', {
      clientId: req.params.clientId,
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to fetch effectiveness data'
    });
  }
});

/**
 * POST /api/effectiveness/:clientId/refresh  
 * Trigger new effectiveness scoring for a client
 */
router.post('/refresh/:clientId', requireAuth, async (req, res) => {
  try {
    const { clientId } = req.params;
    const body = refreshRequestSchema.safeParse(req.body);
    
    if (!body.success) {
      return res.status(400).json({
        code: 'INVALID_REQUEST',
        message: 'Invalid request body',
        details: body.error.errors
      });
    }

    const { force = false } = body.data;

    logger.info('Effectiveness refresh requested', { clientId, force });

    // Get client to verify access and get website URL
    const client = await storage.getClient(clientId);
    if (!client) {
      return res.status(404).json({
        code: 'CLIENT_NOT_FOUND',
        message: 'Client not found'
      });
    }

    // Check user access
    if (req.user?.role !== 'Admin' && req.user?.clientId !== clientId) {
      return res.status(403).json({
        code: 'FORBIDDEN',
        message: 'Access denied'
      });
    }

    // Check cooldown (24 hours) unless forced or user is admin
    if (!force && req.user?.role !== 'Admin' && client.lastEffectivenessRun) {
      const cooldownHours = 24;
      const timeSinceLastRun = Date.now() - new Date(client.lastEffectivenessRun).getTime();
      const cooldownMs = cooldownHours * 60 * 60 * 1000;
      
      if (timeSinceLastRun < cooldownMs) {
        const remainingMs = cooldownMs - timeSinceLastRun;
        const remainingHours = Math.ceil(remainingMs / (60 * 60 * 1000));
        
        return res.status(429).json({
          code: 'COOLDOWN_ACTIVE',
          message: `Effectiveness scoring is on cooldown. Try again in ${remainingHours} hours.`,
          remainingHours
        });
      }
    }

    // Create new run record
    const newRun = await storage.createEffectivenessRun({
      clientId,
      status: 'pending',
      overallScore: null
    });

    // Start scoring process asynchronously
    setImmediate(async () => {
      let runFailed = false;
      try {
        // Track memory usage at start
        const startMemory = process.memoryUsage();
        logger.info('Starting effectiveness scoring', { 
          clientId, 
          runId: newRun.id,
          memoryMB: {
            rss: Math.round(startMemory.rss / 1024 / 1024),
            heapUsed: Math.round(startMemory.heapUsed / 1024 / 1024),
            heapTotal: Math.round(startMemory.heapTotal / 1024 / 1024)
          }
        });
        
        // Clean up any stuck runs first
        await cleanupStuckRuns(clientId);

        // Update progress: Initializing
        await storage.updateEffectivenessRun(newRun.id, {
          status: 'initializing',
          progress: `Starting ${client.name} analysis...`
        });
        
        // Update progress: Scraping website
        await storage.updateEffectivenessRun(newRun.id, {
          status: 'scraping',
          progress: `Collecting ${client.name} data...`
        });
        
        // Score with enhanced approach (90s timeout, includes progressive updates)
        const result = await scoreWithTimeout(client.websiteUrl, newRun.id, 90000);
        
        // Enhanced scoring saves criterion scores progressively during execution

        // AI insights will be generated after all competitor analysis is complete

        // Complete the run with all results (AI insights added later)
        await storage.updateEffectivenessRun(newRun.id, {
          status: 'completed',
          overallScore: result.overallScore.toString(),
          progress: `${client.name} analysis completed. Starting competitor analysis...`,
          screenshotUrl: result.screenshotUrl,
          fullPageScreenshotUrl: result.fullPageScreenshotUrl,
          webVitals: result.webVitals,
          screenshotMethod: result.screenshotMethod || null,
          screenshotError: result.screenshotError || null,
          fullPageScreenshotError: result.fullPageScreenshotError || null
        });

        // Update client with last run time
        await storage.updateClient(clientId, {
          lastEffectivenessRun: new Date()
        });

        // Track memory usage after client completion
        const clientMemory = process.memoryUsage();
        logger.info('Client effectiveness scoring completed', {
          clientId,
          runId: newRun.id,
          overallScore: result.overallScore,
          criteriaCount: result.criterionResults.length,
          hasInsights: !!aiInsights,
          memoryMB: {
            rss: Math.round(clientMemory.rss / 1024 / 1024),
            heapUsed: Math.round(clientMemory.heapUsed / 1024 / 1024),
            heapTotal: Math.round(clientMemory.heapTotal / 1024 / 1024)
          }
        });

        // Score competitors if any
        const competitors = await storage.getCompetitorsByClient(clientId);
        
        if (competitors.length > 0) {
          logger.info('Starting competitor scoring', {
            clientId,
            competitorCount: competitors.length
          });

          for (let index = 0; index < competitors.length; index++) {
            const competitor = competitors[index];
            
            try {
              // Only skip if there's an active pending run (to avoid duplicates)
              // Always create new runs for completed runs since this is a user-requested action
              const activePendingRun = await db
                .select()
                .from(effectivenessRuns)
                .where(and(
                  eq(effectivenessRuns.clientId, clientId),
                  eq(effectivenessRuns.competitorId, competitor.id),
                  eq(effectivenessRuns.status, 'pending'),
                  sql`created_at > NOW() - INTERVAL '${sql.raw('5')} minutes'` // Changed from 1 hour
                ))
                .orderBy(desc(effectivenessRuns.createdAt))
                .limit(1);

              if (activePendingRun.length > 0) {
                logger.info('Skipping competitor - active pending run exists', {
                  clientId,
                  competitorId: competitor.id,
                  competitorDomain: competitor.domain,
                  pendingRunId: activePendingRun[0].id,
                  pendingRunCreated: activePendingRun[0].createdAt
                });
                continue;
              }

              // Add delay between competitors to avoid rate limiting and database conflicts
              if (index > 0) {
                await new Promise(resolve => setTimeout(resolve, 3000)); // 3 second delay
              }
              
              // Small additional delay to prevent database race conditions
              await new Promise(resolve => setTimeout(resolve, 100));

              // Create new run for competitor
              const competitorRun = await storage.createEffectivenessRun({
                clientId,
                competitorId: competitor.id,
                status: 'pending',
                overallScore: null
              });

              logger.info('Scoring competitor website', {
                clientId,
                competitorId: competitor.id,
                competitorDomain: competitor.domain,
                runId: competitorRun.id,
                hasScreenshotKey: !!process.env.SCREENSHOTONE_API_KEY
              });

              // Score competitor website
              let competitorUrl = competitor.domain;
              if (!competitorUrl.startsWith('http://') && !competitorUrl.startsWith('https://')) {
                competitorUrl = `https://${competitorUrl}`;
              }

              // Score competitor with progressive timeout handling for problematic domains
              let timeoutMs = 90000; // Start with 90s
              let competitorResult;
              
              try {
                competitorResult = await scoreWithTimeoutBasic(competitorUrl, timeoutMs);
              } catch (timeoutError) {
                if (timeoutError instanceof Error && timeoutError.message.includes('timeout')) {
                  logger.warn(`Competitor scoring timeout, retrying with extended timeout`, {
                    clientId,
                    competitorDomain: competitor.domain,
                    initialTimeout: timeoutMs,
                    retryTimeout: 150000 // 2.5 minutes
                  });
                  
                  // Retry with longer timeout for problematic domains
                  timeoutMs = 150000;
                  competitorResult = await scoreWithTimeoutBasic(competitorUrl, timeoutMs);
                } else {
                  throw timeoutError;
                }
              }

              // Save competitor results atomically to prevent partial data
              try {
                // Save competitor criterion scores (basic scoring doesn't auto-save)
                for (const criterionResult of competitorResult.criterionResults) {
                  await storage.createCriterionScore({
                    runId: competitorRun.id,
                    criterion: criterionResult.criterion,
                    score: criterionResult.score.toString(),
                    evidence: criterionResult.evidence,
                    passes: criterionResult.passes,
                    tier: getCriterionTier(criterionResult.criterion),
                    completedAt: new Date()
                  });
                }

                // Update competitor run with results (only after all scores saved)
                await storage.updateEffectivenessRun(competitorRun.id, {
                  status: 'completed',
                  overallScore: competitorResult.overallScore.toString(),
                  progress: 'Competitor analysis completed',
                  screenshotUrl: competitorResult.screenshotUrl,
                  fullPageScreenshotUrl: competitorResult.fullPageScreenshotUrl,
                  webVitals: competitorResult.webVitals,
                  screenshotMethod: competitorResult.screenshotMethod || null,
                  screenshotError: competitorResult.screenshotError || null,
                  fullPageScreenshotError: competitorResult.fullPageScreenshotError || null
                });

              } catch (dbSaveError) {
                logger.error('Failed to save competitor results to database', {
                  clientId,
                  competitorId: competitor.id,
                  competitorDomain: competitor.domain,
                  runId: competitorRun.id,
                  error: dbSaveError instanceof Error ? dbSaveError.message : String(dbSaveError)
                });
                
                // Mark run as failed if database save fails
                await storage.updateEffectivenessRun(competitorRun.id, {
                  status: 'failed',
                  progress: `Database save failed: ${dbSaveError instanceof Error ? dbSaveError.message : String(dbSaveError)}`
                }).catch(updateError => {
                  logger.error('Failed to mark competitor run as failed after DB error', {
                    competitorId: competitor.id,
                    runId: competitorRun.id,
                    updateError: updateError instanceof Error ? updateError.message : String(updateError)
                  });
                });
                
                throw dbSaveError;
              }

              logger.info('Competitor scoring completed', {
                clientId,
                competitorId: competitor.id,
                competitorDomain: competitor.domain,
                overallScore: competitorResult.overallScore
              });

            } catch (competitorError) {
              logger.error('Competitor scoring failed', {
                clientId,
                competitorId: competitor.id,
                competitorDomain: competitor.domain,
                error: competitorError instanceof Error ? competitorError.message : String(competitorError)
              });
              
              // Mark the run as failed
              try {
                const failedRun = await db
                  .select()
                  .from(effectivenessRuns)
                  .where(and(
                    eq(effectivenessRuns.clientId, clientId),
                    eq(effectivenessRuns.competitorId, competitor.id),
                    eq(effectivenessRuns.status, 'pending')
                  ))
                  .orderBy(desc(effectivenessRuns.createdAt))
                  .limit(1);

                if (failedRun.length > 0) {
                  await storage.updateEffectivenessRun(failedRun[0].id, {
                    status: 'failed',
                    progress: `Analysis failed: ${competitorError instanceof Error ? competitorError.message : String(competitorError)}`
                  });
                }
              } catch (updateError) {
                logger.warn('Failed to mark competitor run as failed', {
                  competitorId: competitor.id,
                  error: updateError instanceof Error ? updateError.message : String(updateError)
                });
              }
            }
          }
          
          // Generate AI insights after all competitor analysis is complete
          try {
            logger.info('Generating AI insights after competitor analysis', {
              clientId,
              runId: newRun.id,
              competitorCount: competitors.length
            });

            // Import and create insights service
            const { createInsightsService } = await import('../services/effectiveness');
            const insightsService = createInsightsService(storage);

            // Generate insights for the complete analysis (client + competitors)
            const insights = await insightsService.generateInsights(clientId, newRun.id, undefined, 'Admin');
            
            // Update the client run with insights
            await storage.updateEffectivenessRun(newRun.id, {
              aiInsights: insights.insights,
              insightsGeneratedAt: new Date()
            });

            logger.info('AI insights generated successfully after competitor analysis', {
              clientId,
              runId: newRun.id,
              insightsLength: insights.insights?.insight?.length || 0
            });
          } catch (insightsError) {
            logger.error('Failed to generate AI insights after competitor analysis', {
              clientId,
              runId: newRun.id,
              error: insightsError instanceof Error ? insightsError.message : String(insightsError)
            });
            // Continue without insights - don't fail the entire run
          }

          // Track final memory usage
          const finalMemory = process.memoryUsage();
          
          // Update final progress
          await storage.updateEffectivenessRun(newRun.id, {
            progress: `All analysis completed - ${client.name} and ${competitors.length} competitor${competitors.length > 1 ? 's' : ''} analyzed`
          });

          logger.info('All effectiveness analysis completed', {
            clientId,
            runId: newRun.id,
            totalCompetitors: competitors.length,
            finalMemoryMB: {
              rss: Math.round(finalMemory.rss / 1024 / 1024),
              heapUsed: Math.round(finalMemory.heapUsed / 1024 / 1024),
              heapTotal: Math.round(finalMemory.heapTotal / 1024 / 1024)
            },
            memoryGrowth: {
              rss: Math.round((finalMemory.rss - startMemory.rss) / 1024 / 1024),
              heapUsed: Math.round((finalMemory.heapUsed - startMemory.heapUsed) / 1024 / 1024)
            }
          });
        } else {
          // No competitors - generate AI insights for client-only analysis
          try {
            logger.info('No competitors found, generating AI insights for client-only analysis', {
              clientId,
              runId: newRun.id
            });

            // Import and create insights service
            const { createInsightsService } = await import('../services/effectiveness');
            const insightsService = createInsightsService(storage);

            // Generate insights for client analysis
            const insights = await insightsService.generateInsights(clientId, newRun.id, undefined, 'Admin');
            
            // Update the client run with insights
            await storage.updateEffectivenessRun(newRun.id, {
              aiInsights: insights.insights,
              insightsGeneratedAt: new Date(),
              progress: `Analysis completed - ${client.name} analyzed`
            });

            logger.info('AI insights generated successfully for client-only analysis', {
              clientId,
              runId: newRun.id,
              insightsLength: insights.insights?.insight?.length || 0
            });
          } catch (insightsError) {
            logger.error('Failed to generate AI insights for client-only analysis', {
              clientId,
              runId: newRun.id,
              error: insightsError instanceof Error ? insightsError.message : String(insightsError)
            });
            // Continue without insights - don't fail the entire run
          }
        }

      } catch (scoringError) {
        runFailed = true;
        logger.error('Effectiveness scoring failed', {
          clientId,
          runId: newRun.id,
          error: scoringError instanceof Error ? scoringError.message : String(scoringError)
        });
        
        // Always mark as failed
        await storage.updateEffectivenessRun(newRun.id, {
          status: 'failed',
          progress: `Analysis failed: ${scoringError instanceof Error ? scoringError.message : 'Unknown error'}`
        });
      } finally {
        // Ensure we don't leave runs in pending state
        if (!runFailed) {
          const finalRun = await storage.getEffectivenessRun(newRun.id);
          if (finalRun && ['pending', 'initializing', 'scraping', 'analyzing'].includes(finalRun.status)) {
            await storage.updateEffectivenessRun(newRun.id, {
              status: 'failed',
              progress: 'Run did not complete properly'
            });
          }
        }
        
        // Clean up browser resources to prevent zombie processes
        try {
          await screenshotService.cleanup();
          logger.info('Browser cleanup completed successfully', { runId: newRun.id });
        } catch (cleanupError) {
          logger.error('Browser cleanup failed', { 
            runId: newRun.id,
            error: cleanupError instanceof Error ? cleanupError.message : String(cleanupError)
          });
        }
      }
    });

    res.json({
      message: 'Effectiveness scoring completed',
      runId: newRun.id,
      status: 'completed'
    });

  } catch (error) {
    logger.error('Failed to start effectiveness refresh', {
      clientId: req.params.clientId,
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to start effectiveness scoring'
    });
  }
});

/**
 * GET /api/effectiveness/:runId/evidence/:criterion
 * Get detailed evidence for a specific criterion
 */
router.get('/:runId/evidence/:criterion', requireAuth, async (req, res) => {
  try {
    const { runId, criterion } = req.params;
    
    // Get the run to verify access
    const run = await storage.getEffectivenessRun(runId);
    if (!run) {
      return res.status(404).json({
        code: 'RUN_NOT_FOUND',
        message: 'Effectiveness run not found'
      });
    }

    // Check user access
    if (req.user?.role !== 'Admin' && req.user?.clientId !== run.clientId) {
      return res.status(403).json({
        code: 'FORBIDDEN',
        message: 'Access denied'
      });
    }

    // Get the specific criterion score
    const scores = await storage.getCriterionScores(runId);
    const criterionScore = scores.find(s => s.criterion === criterion);

    if (!criterionScore) {
      return res.status(404).json({
        code: 'EVIDENCE_NOT_FOUND',
        message: `No evidence found for criterion: ${criterion}`
      });
    }

    res.json({
      runId,
      criterion,
      score: criterionScore.score,
      evidence: criterionScore.evidence,
      passes: criterionScore.passes
    });

  } catch (error) {
    logger.error('Failed to fetch evidence', {
      runId: req.params.runId,
      criterion: req.params.criterion,
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to fetch evidence'
    });
  }
});

/**
 * GET /api/effectiveness/:runId/evidence/all
 * Get all evidence data for an effectiveness run (used by evidence drawer)
 */
router.get('/:runId/evidence/all', requireAuth, async (req, res) => {
  try {
    const { runId } = req.params;
    
    // Get the run to verify access
    const run = await storage.getEffectivenessRun(runId);
    if (!run) {
      return res.status(404).json({
        code: 'RUN_NOT_FOUND',
        message: 'Effectiveness run not found'
      });
    }

    // Check user access
    if (req.user?.role !== 'Admin' && req.user?.clientId !== run.clientId) {
      return res.status(403).json({
        code: 'FORBIDDEN',
        message: 'Access denied'
      });
    }

    // Get all criterion scores for this run
    const criterionScores = await storage.getCriterionScores(runId);
    
    res.json({
      run: {
        ...run,
        criterionScores
      }
    });

  } catch (error) {
    logger.error('Failed to fetch all evidence', {
      runId: req.params.runId,
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to fetch evidence'
    });
  }
});

/**
 * POST /api/effectiveness/:runId/insights
 * Generate AI insights for an effectiveness run
 */
router.post('/:runId/insights', requireAuth, async (req, res) => {
  try {
    const { runId } = req.params;
    
    // Get the run to verify access
    const run = await storage.getEffectivenessRun(runId);
    if (!run) {
      return res.status(404).json({
        code: 'RUN_NOT_FOUND',
        message: 'Effectiveness run not found'
      });
    }

    // Check user access
    if (req.user?.role !== 'Admin' && req.user?.clientId !== run.clientId) {
      return res.status(403).json({
        code: 'FORBIDDEN',
        message: 'Access denied'
      });
    }

    // Check if run is completed
    if (run.status !== 'completed') {
      return res.status(400).json({
        code: 'RUN_NOT_COMPLETED',
        message: 'Effectiveness run must be completed before generating insights'
      });
    }

    // Check if insights already exist
    if (run.aiInsights) {
      return res.json({
        runId,
        insights: run.aiInsights,
        generatedAt: run.insightsGeneratedAt
      });
    }

    logger.info('Generating AI insights for run', { runId });

    // Import and create insights service
    const { createInsightsService } = await import('../services/effectiveness');
    const insightsService = createInsightsService(storage);

    // Generate insights
    const result = await insightsService.generateInsights(run.clientId, runId, req.user?.clientId, req.user?.role);

    // Update run with insights
    await storage.updateEffectivenessRun(runId, {
      aiInsights: result.insights,
      insightsGeneratedAt: new Date()
    });

    res.json({
      runId,
      insights: result.insights,
      generatedAt: new Date()
    });

  } catch (error) {
    logger.error('Failed to generate insights', {
      runId: req.params.runId,
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to generate insights'
    });
  }
});

/**
 * GET /api/effectiveness/config
 * Get effectiveness scoring configuration (admin only)
 */
router.get('/config', requireAdmin, async (req, res) => {
  try {
    const config = await configManager.getConfig();
    res.json(config);
  } catch (error) {
    logger.error('Failed to fetch effectiveness config', {
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to fetch configuration'
    });
  }
});

/**
 * PUT /api/effectiveness/config
 * Update effectiveness scoring configuration (admin only)
 */
router.put('/config', requireAdmin, async (req, res) => {
  try {
    const updated = await configManager.updateConfig(req.body);
    res.json(updated);
  } catch (error) {
    logger.error('Failed to update effectiveness config', {
      error: error instanceof Error ? error.message : String(error)
    });

    res.status(500).json({
      code: 'INTERNAL_ERROR',
      message: 'Failed to update configuration'
    });
  }
});

export default router;