/**
 * Clean Effectiveness Service
 * 
 * Extracted from proven test patterns in test_effectiveness_complete.ts
 * Simple, reliable, and honest about async operations.
 */

import { performance } from 'perf_hooks';
import { db } from '../db.js';
import { effectivenessRuns, criterionScores } from '../../shared/schema.js';
import { storage } from '../storage.js';
import { EnhancedWebsiteEffectivenessScorer } from './effectiveness/enhancedScorer.js';
import { parallelDataCollector } from './effectiveness/parallelDataCollector.js';
import { EffectivenessConfigManager } from './effectiveness/config.js';
import { eq, and, desc, isNull } from 'drizzle-orm';
import { logger } from '../utils/logging/logger.js';
import { createProgressTracker, getProgressTracker, clearProgressTracker } from './effectiveness/progressTracker.js';

interface AnalysisProgress {
  runId: string;
  status: 'pending' | 'initializing' | 'scraping' | 'analyzing' | 
          'tier1_analyzing' | 'tier1_complete' | 'tier2_analyzing' | 
          'tier2_complete' | 'tier3_analyzing' | 'completed' | 'failed';
  progress: number;
  progressDetail: string;
  currentStep?: string;
}

interface AnalysisResult {
  runId: string;
  overallScore: number;
  criterionScores: any[];
  status: 'completed' | 'failed';
}

class EffectivenessService {
  private configManager: EffectivenessConfigManager;
  private scorer: EnhancedWebsiteEffectivenessScorer;
  private runningJobs = new Map<string, AnalysisProgress>();

  constructor() {
    this.configManager = new EffectivenessConfigManager();
    this.scorer = new EnhancedWebsiteEffectivenessScorer();
  }

  /**
   * Start effectiveness analysis - Returns immediately with runId
   * Based on test pattern: create run first, then process async
   */
  async startAnalysis(clientId: string, force = false): Promise<{ runId: string }> {
    logger.info('Starting effectiveness analysis', { clientId, force });

    // Get client
    const client = await storage.getClient(clientId);
    if (!client) {
      throw new Error(`Client not found: ${clientId}`);
    }

    // Check for existing pending runs (unless forced)
    if (!force) {
      const existingPending = await db
        .select()
        .from(effectivenessRuns)
        .where(and(
          eq(effectivenessRuns.clientId, clientId),
          isNull(effectivenessRuns.competitorId),
          eq(effectivenessRuns.status, 'pending')
        ))
        .limit(1);

      if (existingPending.length > 0) {
        logger.info('Returning existing pending run', { 
          clientId, 
          runId: existingPending[0].id 
        });
        return { runId: existingPending[0].id };
      }
    }

    // Create new run record
    const run = await storage.createEffectivenessRun({
      clientId,
      status: 'pending',
      overallScore: null
    });

    logger.info('Created new effectiveness run', { 
      clientId, 
      runId: run.id 
    });

    // Initialize progress tracking
    this.runningJobs.set(run.id, {
      runId: run.id,
      status: 'pending',
      progress: 0,
      progressDetail: 'Analysis queued',
      currentStep: 'Initializing'
    });

    // Start async processing (don't await)
    setImmediate(() => this.processAnalysisAsync(run.id, client));

    return { runId: run.id };
  }

  /**
   * Get analysis progress for a specific run
   */
  async getProgress(runId: string): Promise<AnalysisProgress | null> {
    // Check in-memory first for active jobs
    const activeJob = this.runningJobs.get(runId);
    if (activeJob) {
      return activeJob;
    }

    // Check database for completed/failed runs
    const run = await storage.getEffectivenessRun(runId);
    if (!run) {
      return null;
    }

    return {
      runId: run.id,
      status: run.status,
      progress: this.parseProgress(run.progress),
      progressDetail: run.progressDetail || run.progress || 'No progress info',
      currentStep: run.status === 'completed' ? 'Completed' : 'Processing'
    };
  }

  /**
   * Get latest completed analysis for client
   * Based on our fixed storage method
   */
  async getLatestResults(clientId: string): Promise<any> {
    return await storage.getLatestEffectivenessRun(clientId);
  }

  /**
   * Async processing method - Based on test file patterns
   * Follows the exact step structure from test_effectiveness_complete.ts
   */
  private async processAnalysisAsync(runId: string, client: any): Promise<void> {
    const tracker = createProgressTracker();
    
    try {
      logger.info('Starting async analysis processing', { runId, clientId: client.id });

      // Get competitors and initialize tracker
      const competitors = await storage.getCompetitorsByClient(client.id);
      tracker.setCompetitorCount(competitors.length);
      
      // Update initial progress
      await this.syncProgressFromTracker(runId, tracker);

      // Process client (main analysis)
      await this.processClient(runId, client, tracker);

      // Process competitors
      await this.processCompetitors(runId, client.id, competitors, tracker);

      // Complete analysis
      await this.completeAnalysis(runId, tracker);

    } catch (error) {
      logger.error('Analysis failed', { runId, error: error instanceof Error ? error.message : String(error) });
      
      await storage.updateEffectivenessRun(runId, {
        status: 'failed',
        progress: `Analysis failed: ${error instanceof Error ? error.message : String(error)}`
      });

      // Update in-memory tracking
      const job = this.runningJobs.get(runId);
      if (job) {
        job.status = 'failed';
        job.progressDetail = `Failed: ${error instanceof Error ? error.message : String(error)}`;
      }
    } finally {
      // Clean up progress tracker
      clearProgressTracker();
      
      // Clean up in-memory tracking after completion/failure
      setTimeout(() => this.runningJobs.delete(runId), 60000); // Keep for 1 minute for status checks
    }
  }

  /**
   * Process client analysis - Extracted from test file
   */
  private async processClient(runId: string, client: any, tracker: any): Promise<void> {
    const url = client.websiteUrl;
    
    // Start client analysis
    tracker.startClient(client.domain || client.websiteUrl);
    await this.syncProgressFromTracker(runId, tracker);
    
    const config = await this.configManager.getConfig();
    const dataResult = await parallelDataCollector.collectAllData(url, config);
    
    // Run Progressive Analysis - now without progress conflicts
    const finalResults = await this.scorer.scoreWebsiteProgressive(url, runId);

    // Mark all 8 criteria as complete for client
    for (let i = 0; i < 8; i++) {
      tracker.completeCriterion(`criterion_${i+1}`, true);
    }
    await this.syncProgressFromTracker(runId, tracker);

    // Log results structure for debugging
    logger.info('Scorer returned results', { 
      runId, 
      hasOverallScore: !!finalResults.overallScore,
      hasCriterionResults: !!finalResults.criterionResults,
      criteriaCount: finalResults.criterionResults?.length,
      hasScreenshotUrl: !!finalResults.screenshotUrl,
      hasFullPageUrl: !!finalResults.fullPageScreenshotUrl
    });

    // Save to database atomically - use finalResults for screenshot URLs since scorer handles its own data collection
    await this.saveClientResults(runId, finalResults, finalResults);
  }

  /**
   * Process competitors - Run effectiveness analysis on competitor URLs
   */
  private async processCompetitors(mainRunId: string, clientId: string, competitors: any[], tracker: any): Promise<void> {
    if (competitors.length === 0) {
      logger.info('No competitors to process', { mainRunId });
      return;
    }

    logger.info('Processing competitors', { mainRunId, count: competitors.length });
    
    // Process competitors sequentially with incremental progress updates
    let successful = 0;
    
    for (let i = 0; i < competitors.length; i++) {
      const competitor = competitors[i];
      tracker.startCompetitor(competitor.domain, i);
      await this.syncProgressFromTracker(mainRunId, tracker);
      
      try {
        logger.info('Starting competitor analysis', { 
          mainRunId, 
          competitorId: competitor.id, 
          competitorDomain: competitor.domain,
          progress: `${i + 1}/${competitors.length}`
        });

        // Create competitor effectiveness run
        const competitorRun = await storage.createEffectivenessRun({
          clientId,
          competitorId: competitor.id,
          status: 'pending',
          overallScore: null
        });

        // Process competitor website using same analysis flow as client
        const competitorUrl = competitor.domain.startsWith('http') 
          ? competitor.domain 
          : `https://${competitor.domain}`;

        // Get config for analysis
        const config = await this.configManager.getConfig();
        
        // Collect data for competitor
        const dataResult = await parallelDataCollector.collectAllData(competitorUrl, config);
        
        // Run progressive analysis without progress callback to avoid conflicts
        const finalResults = await this.scorer.scoreWebsiteProgressive(competitorUrl, competitorRun.id);

        // Save competitor results using same structure as client
        await this.saveCompetitorResults(competitorRun.id, finalResults, dataResult);
        
        logger.info('Competitor analysis completed', {
          mainRunId,
          competitorId: competitor.id,
          competitorRunId: competitorRun.id,
          overallScore: finalResults.overallScore
        });

        successful++;
        
        // Mark competitor as complete and update main run progress
        tracker.completeCompetitor();
        await this.syncProgressFromTracker(mainRunId, tracker);
        
        // Also update with traditional progress for compatibility
        const progressPercent = 40 + ((i + 1) / competitors.length) * 50; // 40% to 90%
        await this.updateProgress(mainRunId, 'analyzing', progressPercent, 
          `Analyzed ${i + 1} of ${competitors.length} competitors`);

      } catch (error) {
        logger.error('Competitor analysis failed', {
          mainRunId,
          competitorId: competitor.id,
          competitorDomain: competitor.domain,
          error: error instanceof Error ? error.message : String(error)
        });
        // Continue with next competitor
      }
    }
    
    logger.info('All competitor analyses completed', {
      mainRunId,
      total: competitors.length,
      successful,
      failed: competitors.length - successful
    });
  }

  /**
   * Complete analysis - Only mark as completed if client actually has full results
   */
  private async completeAnalysis(runId: string, tracker: any): Promise<void> {
    // Add mutex check - prevent double completion
    const job = this.runningJobs.get(runId);
    if (job?.status === 'completed') {
      return; // Already completed, don't update again
    }

    tracker.startInsights();
    await this.syncProgressFromTracker(runId, tracker);
    
    // Small delay to simulate insights generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    tracker.complete();
    await this.syncProgressFromTracker(runId, tracker);
    // Check if client run actually completed successfully
    const run = await storage.getEffectivenessRun(runId);
    if (!run) {
      logger.error('Cannot complete analysis - run not found', { runId });
      return;
    }

    // Get criterion scores to check completeness
    const scores = await db.select().from(criterionScores).where(eq(criterionScores.runId, runId));
    const expectedCriteria = 8; // We expect 8 criteria for complete analysis
    const hasCompleteResults = scores.length >= expectedCriteria;

    if (hasCompleteResults) {
      // Truly completed - all criteria succeeded
      await storage.updateEffectivenessRun(runId, {
        status: 'completed',
        progress: 'Analysis completed successfully'
      });

      const job = this.runningJobs.get(runId);
      if (job) {
        job.status = 'completed';
        job.progress = 100;
        job.progressDetail = 'Analysis completed successfully';
      }

      logger.info('Analysis completed successfully', { runId, criteriaCompleted: scores.length });
    } else {
      // Partial results - mark as failed but results exist (will be handled as "partial" by frontend)
      await storage.updateEffectivenessRun(runId, {
        status: 'failed',
        progress: `Analysis completed with limitations - ${scores.length}/${expectedCriteria} criteria`
      });

      const job = this.runningJobs.get(runId);
      if (job) {
        job.status = 'failed';
        job.progress = 95; // High progress but not complete
        job.progressDetail = `Partial results available - ${scores.length}/${expectedCriteria} criteria completed`;
      }

      logger.info('Analysis completed with partial results', { 
        runId, 
        criteriaCompleted: scores.length, 
        expectedCriteria,
        status: 'partial_success' 
      });
    }
  }

  /**
   * Save competitor results atomically - Same structure as client results
   */
  private async saveCompetitorResults(runId: string, results: any, dataResult: any): Promise<void> {
    try {
      logger.info('Starting competitor database save transaction', { 
        runId, 
        overallScore: results.overallScore, 
        criteriaCount: results.criterionResults?.length 
      });
      
      await db.transaction(async (tx) => {
        // Update run with final score
        await tx.update(effectivenessRuns)
          .set({
            overallScore: results.overallScore.toString(),
            status: 'completed',
            screenshotUrl: dataResult.screenshotUrl,
            fullPageScreenshotUrl: dataResult.fullPageScreenshotUrl
          })
          .where(eq(effectivenessRuns.id, runId));

        logger.info('Updated competitor effectiveness run with final results', { runId });

        // Save criterion scores
        for (const criterion of results.criterionResults) {
          await tx.insert(criterionScores).values({
            runId: runId,
            criterion: criterion.criterion,
            score: criterion.score.toString(),
            evidence: criterion.evidence,
            passes: criterion.passes,
            tier: criterion.tier || 1
          });
        }
        
        logger.info('Saved competitor criterion scores', { runId, count: results.criterionResults.length });
      });
      
      logger.info('Competitor database transaction completed successfully', { runId });
    } catch (error) {
      logger.error('Competitor database save transaction failed', { 
        runId, 
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  /**
   * Save client results atomically - Based on test patterns
   */
  private async saveClientResults(runId: string, results: any, dataResult: any): Promise<void> {
    try {
      logger.info('Starting database save transaction', { 
        runId, 
        overallScore: results.overallScore, 
        criteriaCount: results.criterionResults?.length 
      });
      
      await db.transaction(async (tx) => {
        // Update run with final score
        await tx.update(effectivenessRuns)
          .set({
            overallScore: results.overallScore.toString(),
            status: 'completed', // Analysis finished successfully
            screenshotUrl: dataResult.screenshotUrl,
            fullPageScreenshotUrl: dataResult.fullPageScreenshotUrl
          })
          .where(eq(effectivenessRuns.id, runId));

        logger.info('Updated effectiveness run with final results', { runId });

        // Save criterion scores
        for (const criterion of results.criterionResults) {
          await tx.insert(criterionScores).values({
            runId: runId,
            criterion: criterion.criterion,
            score: criterion.score.toString(),
            evidence: criterion.evidence,
            passes: criterion.passes,
            tier: criterion.tier || 1
          });
        }
        
        logger.info('Saved criterion scores', { runId, count: results.criterionResults.length });
      });
      
      logger.info('Database transaction completed successfully', { runId });
    } catch (error) {
      logger.error('Database save transaction failed', { 
        runId, 
        error: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : undefined
      });
      throw error;
    }
  }

  /**
   * Update progress tracking
   */
  private async updateProgress(runId: string, status: any, progress: number, detail: string): Promise<void> {
    // Update in-memory
    const job = this.runningJobs.get(runId);
    if (job) {
      job.status = status;
      job.progress = progress;
      job.progressDetail = detail;
    }

    // Update database - SAVE BOTH progress and progressDetail
    await storage.updateEffectivenessRun(runId, {
      status,
      progress: `${progress}%`,
      progressDetail: detail  // ADD THIS LINE - save the actual progress text!
    });

    logger.info('Progress updated', { 
      runId: runId.slice(0, 8), 
      status, 
      progress, 
      detail 
    });
  }

  /**
   * Sync progress from tracker to database and in-memory tracking atomically
   */
  private async syncProgressFromTracker(runId: string, tracker: any): Promise<void> {
    const state = tracker.getState();
    
    try {
      // Update database with smooth progress - use atomic transaction to prevent race conditions
      await db.transaction(async (tx) => {
        await tx.update(effectivenessRuns)
          .set({
            status: state.currentPhase === 'completed' ? 'completed' : 'analyzing',
            progress: state.message,
            updatedAt: new Date()
          })
          .where(eq(effectivenessRuns.id, runId));
      });

      // Update in-memory tracking after successful database update
      const job = this.runningJobs.get(runId);
      if (job) {
        job.status = state.currentPhase === 'completed' ? 'completed' : 'analyzing';
        job.progress = state.overallPercent;
        job.progressDetail = state.message;
        job.currentStep = state.currentOperation;
      }

      logger.info('Progress synced from tracker', { 
        runId: runId.slice(0, 8), 
        percent: state.overallPercent,
        phase: state.currentPhase,
        message: state.message 
      });
    } catch (error) {
      logger.error('Failed to sync progress from tracker', {
        runId: runId.slice(0, 8),
        error: error instanceof Error ? error.message : String(error)
      });
      // Don't throw - progress sync failures shouldn't break the analysis
    }
  }

  /**
   * Parse progress percentage from string
   */
  private parseProgress(progress: string | null | undefined): number {
    if (!progress) return 0;
    const match = progress.match(/(\d+)%/);
    return match ? parseInt(match[1]) : 0;
  }
}

export const effectivenessService = new EffectivenessService();
export default effectivenessService;