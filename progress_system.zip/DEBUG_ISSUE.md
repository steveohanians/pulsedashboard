# Progress System Debug Issue

## SYMPTOMS:
1. Frontend shows "Analyzing your website" with no progress percentage
2. Progress bar stays at 0%
3. Eventually shows "Analysis completed but no scores available"
4. Database shows `Progress Message: null`

## ROOT CAUSE:
The progressTracker updates are NOT being saved to the database during the run.

## KEY ISSUE:
In `effectivenessRoutes.ts:53-75`, the `scoreWithTimeout` function has a progress callback that should:
1. Call `tracker.completeCriterion()` when criteria complete
2. Save tracker state with `tracker.getProgressString()` and `tracker.getState()`
3. Update database with new progress data

But the database shows `Progress Message: null`, meaning this callback isn't working.

## WHAT TO CHECK:
1. Is the progress callback being called at all?
2. Is `enhancedScorer.ts` sending the right `progressDetail` structure?
3. Is the `tracker.completeCriterion()` being called?
4. Is the database update failing?

## FIX NEEDED:
The integration between `enhancedScorer` → `effectivenessRoutes` callback → `progressTracker` → database is broken.

The progressTracker code itself works (tested in isolation), but the integration chain is failing.